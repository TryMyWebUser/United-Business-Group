$(function () {
    $('#recentOrders').DataTable();
    $('#recentOrders1').DataTable();
    $('#recentOrders2').DataTable();
    $('#recentOrders3').DataTable();
    $('#recentOrders4').DataTable();
  });