new GLightbox({
  touchNavigation: true,
  loop: true,
  width: "90vw",
  height: "90vh",
});

var lightboxDescription = GLightbox({
  selector: '.descriptionbox'
});

//   var lightboxVideo = GLightbox({
//     selector: '.glightboxvideo'
//   });

//   var lightboxVideo = GLightbox({
//     selector: '.gbox'
//   });